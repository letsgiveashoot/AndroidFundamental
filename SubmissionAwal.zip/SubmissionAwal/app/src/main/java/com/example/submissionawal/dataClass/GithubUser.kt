package com.example.submissionawal.dataClass

data class GithubUser(
    val login : String,
    val avatar_url : String,
    val id : String
)
package com.example.submissionawal.dataClass

data class GithubUserResponse(
    val items : ArrayList<GithubUser>
)
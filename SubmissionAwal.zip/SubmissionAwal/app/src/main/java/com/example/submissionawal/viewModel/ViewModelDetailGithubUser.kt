package com.example.submissionawal.viewModel

import com.example.submissionawal.dataClass.DetailGithubUser
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.submissionawal.API.RetrofitDec
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ViewModelDetailGithubUser : ViewModel() {

    val listDetailUserGithub = MutableLiveData<DetailGithubUser>()

    fun setDetailGithubUser(username: String) {
        RetrofitDec.api
            .getDetailUser(username)
            .enqueue(object : Callback<DetailGithubUser> {
                override fun onResponse(
                    call: Call<DetailGithubUser>,
                    response: Response<DetailGithubUser>
                ) {
                    if (response.isSuccessful) {
                        listDetailUserGithub.postValue(response.body())
                    }
                }

                override fun onFailure(call: Call<DetailGithubUser>, t: Throwable) {
                    Log.d("Failure", t.message.toString())
                }

            })
    }

    fun getCariDetailUser(): LiveData<DetailGithubUser> {
        return listDetailUserGithub
    }
}